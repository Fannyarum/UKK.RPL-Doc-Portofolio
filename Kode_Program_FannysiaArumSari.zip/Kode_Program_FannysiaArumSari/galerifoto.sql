-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 21, 2024 at 11:59 AM
-- Server version: 8.0.30
-- PHP Version: 8.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `galerifoto`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE `album` (
  `AlbumID` int NOT NULL,
  `NamaAlbum` varchar(255) NOT NULL,
  `Deskripsi` text NOT NULL,
  `TanggalDibuat` date NOT NULL,
  `UserID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`AlbumID`, `NamaAlbum`, `Deskripsi`, `TanggalDibuat`, `UserID`) VALUES
(1, 'Buah', 'Kumpulan foto mengenai beragam jenis buah yang saya temui.', '2024-02-20', 1),
(2, 'Pemandangan', 'Keindahan alam menyegarkan, berisikan view spot dari negeri indonesia yang memukau.', '2024-02-20', 1),
(3, 'Sweet Bang', 'Kehidupan manis yang penuh senyuman bersama Himalaya yang dinginnnn, cinta dan harapan akan tumbuh pada album ini awokawok.', '2024-02-20', 3),
(4, 'Bunga', 'Album yang berisikan kumpulan foto bunga yang melukis palet warna sempurna dari alam.', '2024-02-20', 2),
(6, 'haimanis', 'poke', '2024-02-20', 1),
(7, 'Home', 'Home sweet home', '2024-02-20', 5),
(8, 'Joko', 'Albumnya joko', '2024-02-21', 6);

-- --------------------------------------------------------

--
-- Table structure for table `foto`
--

CREATE TABLE `foto` (
  `FotoID` int NOT NULL,
  `JudulFoto` varchar(255) NOT NULL,
  `DeskripsiFoto` text NOT NULL,
  `TanggalUnggah` date NOT NULL,
  `LokasiFile` varchar(255) NOT NULL,
  `AlbumID` int NOT NULL,
  `UserID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `foto`
--

INSERT INTO `foto` (`FotoID`, `JudulFoto`, `DeskripsiFoto`, `TanggalUnggah`, `LokasiFile`, `AlbumID`, `UserID`) VALUES
(2, 'Perahu Karam', 'Gambaran perahu yang sudah menjadi kerangkeng, keberadaannya yaitu di pinggir sungai ogan kecamatan OKU bertepatan di seberang rumah nenek saya.', '2024-02-20', 'public/inifoto/BUcoeDQ0OovzIZts8wFksiOF9wZC4PusiLTWfdB3.jpg', 2, 1),
(3, 'Gandaria', 'Buah ini menyerupai buah mangga dengan ukuran yang lebih kecil. Biasanya keluarga saya mencampurkan buah gandaria yang belum matang ke masakan rasanya asam.', '2024-02-20', 'public/inifoto/ZzcaFBbxJx98xmJykURxjghrjsDHoJJDImMRsmY5.jpg', 1, 1),
(8, 'Special Gift', 'Boneka kejutan yang saya dapatkan hari ini. On this special day, dia mampu menyampaikan perasaannya, sungguh suatu hal yang langka terjadi.', '2024-02-20', 'public/inifoto/lSHLoHArxBJmAySLAf6nv8WjWHxdbjiXHJvxOaDM.jpg', 3, 3),
(9, 'Bunga Alamanda', 'Bunga ini sering kita temukan di halaman rumah karena cara menanamnya sangatlah mudah hanya perlu mengambil tangkai dan ditanam, untuk selanjutnya tergantung merawatnya saja.', '2024-02-20', 'public/inifoto/twMcsADxlJe1oMSJc6Go9RXlSnjlEqzVh4Q8iA0M.jpg', 4, 2),
(15, 'Bunga Kana', 'Bunga kana adalah tanaman yang tergolong tanaman luar. Biasanya bunga ini ditemukan dimana saja baik di hutan, pekarangan rumah maupun taman umum walaupun tidak sering kita temukan.', '2024-02-20', 'public/inifoto/aKN9XmyRsYTryHkO4P3bRedEqIRZCJGAHz9wKLxq.jpg', 4, 2),
(16, 'View Jendela', 'Ini sungguh melelahkan, ibaratkan api dengan sedikit bara yang dipaksa terus menyala. Sesekali saya ingin singgah di perempatan pohon jeruk. Mengambil jeda dan membuat terobosan baru.', '2024-02-20', 'public/inifoto/KO5IR1LGBXaHDIXbOoiYVwmK68YOS1KERcyXqAld.jpg', 7, 5),
(18, 'Prasangka', 'Aku merasa sangat terikat dengan aroma yang asing ini. Dikala tali yang mengikat itu longgar, perasaan memporak porandakan rasa.', '2024-02-20', 'public/inifoto/ph0hUJ56wPCZ1LhVMfk0rCZR5aPqjK92dztHlsah.jpg', 7, 5),
(19, 'Apaan?', 'Katanya coklat bisa naikin hormon endorfin lohh.. jikalau sedih ya makannn ini aja gih. Saranku ya, sekian.', '2024-02-20', 'public/inifoto/RyZoVyIi9pJ5qN4NxnBzv27lfpuIlSd4EDLdSSad.jpg', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `komentarfoto`
--

CREATE TABLE `komentarfoto` (
  `KomentarID` int NOT NULL,
  `FotoID` int NOT NULL,
  `UserID` int NOT NULL,
  `IsiKomentar` text NOT NULL,
  `TanggalKomentar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `komentarfoto`
--

INSERT INTO `komentarfoto` (`KomentarID`, `FotoID`, `UserID`, `IsiKomentar`, `TanggalKomentar`) VALUES
(1, 3, 1, 'Mau jadi apa kamu', '2024-02-20'),
(2, 3, 2, 'sama kayak binjai gak sih?', '2024-02-20'),
(3, 15, 1, 'bunganya bagus banget kakkkk', '2024-02-21'),
(4, 16, 4, 'namanya fox moba kok puitis bang', '2024-02-21'),
(5, 16, 5, 'serlok dek', '2024-02-21'),
(6, 20, 6, 'ini joko', '2024-02-21'),
(7, 9, 1, 'Bagus bunga nya', '2024-02-21'),
(8, 9, 1, 'cuma warna kuning atau ada warna lain??', '2024-02-21');

-- --------------------------------------------------------

--
-- Table structure for table `likefoto`
--

CREATE TABLE `likefoto` (
  `LikeID` int NOT NULL,
  `FotoID` int NOT NULL,
  `UserID` int NOT NULL,
  `TanggalLike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `likefoto`
--

INSERT INTO `likefoto` (`LikeID`, `FotoID`, `UserID`, `TanggalLike`) VALUES
(1, 3, 1, '2024-02-20'),
(2, 4, 2, '2024-02-20'),
(3, 2, 2, '2024-02-20'),
(4, 8, 1, '2024-02-20'),
(5, 3, 2, '2024-02-20'),
(6, 15, 1, '2024-02-21'),
(7, 16, 5, '2024-02-21'),
(8, 3, 5, '2024-02-21'),
(9, 20, 6, '2024-02-21'),
(10, 9, 1, '2024-02-21');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `NamaLengkap` varchar(255) NOT NULL,
  `Alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `Username`, `Password`, `Email`, `NamaLengkap`, `Alamat`) VALUES
(1, 'Arliossthemenn', '111', 'arliostenker@gmail.com', 'Arlios Ganteng', 'Jl. Lvl 6'),
(2, 'Lawtrao', '123', 'trafalgar@gmail.com', 'Trafalgar Water Law', 'Jl. Bepooo kumaaa'),
(3, 'HimalayaVynn', '333', 'gunung@gmail.com', 'Himalaya Everest Collab', 'Jl. Cool banget'),
(4, 'Koala', '1010', 'koala@gmail.com', 'Kokoalaala', 'Jl. Hutan'),
(5, 'Foxmoba', '1206', 'jonson@gmail.com', 'Franco Rubah Merah', 'Jl. Kapal Pesiar'),
(6, 'Joko', '111', 'joko@gmail.com', 'Joko Adi', 'Jl. Tje');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`AlbumID`);

--
-- Indexes for table `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`FotoID`);

--
-- Indexes for table `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD PRIMARY KEY (`KomentarID`);

--
-- Indexes for table `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`LikeID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album`
--
ALTER TABLE `album`
  MODIFY `AlbumID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `foto`
--
ALTER TABLE `foto`
  MODIFY `FotoID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `komentarfoto`
--
ALTER TABLE `komentarfoto`
  MODIFY `KomentarID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `likefoto`
--
ALTER TABLE `likefoto`
  MODIFY `LikeID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
