<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
            body {
            background:url('img/bgg.jpg');
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .customjok{
            background:#fff; 
            padding: 30px;
            border-radius: 10px;
        }
        .btn{
            background-color:#A498C3;
            padding: 6px 10px;
            border-radius:20px;
        }
        .inpucol{
            background-color:#D3D3D3;
            border-radius:25px;
        }
        p{
            color: #C64B8C;
            font-family: 'Comic Sans MS', cursive;
            
        }
        span{
            font-family: 'Comic Sans MS';
            color: #784B84;
        }
    </style>
  </head>
  <body>
    <section>
        <div class="customjok" style="box-shadow:2px 3px 20px rgba(0, 0, 0, 0.5);">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-xl-5 order-md-last">
                            <div>
                                <img src="img/logo.png" class="img-fluid">
                                <p class="fw-bold text-center fs-1" style="font-family: 'Comic Sans MS'"><span>Galeri</span>Foto</p>
                            </div>
                        </div>
                        <div class="col-xl-4">
                            <div class="p-5">
                                <h1 class="fs-8 text-center">Login</h1>
                                <br>
                                <p class="text-center fw-bold text-danger">{{session()->get('warning')}}</p>
                                <form action="/login" method="post">
                                    @csrf
                                    <div class="text-center">
                                        <label class="fw-bold">Masukkan Email :</label>
                                        <input type="email" name="Email" required class="form-control form-control-lg inpucol"/>
                                    </div>
                                <br>

                                    <div class="text-center">
                                        <label class="fw-bold">Masukkan Password :</label>
                                        <input type="Password" name="Password" required class="form-control form-control-lg inpucol" />
                                    </div>
                                <br>
                                    <div class="text-center">
                                        <p class="small fw-bold text-dark">Belum punya akun? <a href="/register" style="color:#A498C3;">Daftar</a> disini</p>
                                        <br>
                                        <input type="submit" value="Masuk" class="fw-bold btn" 
                                        style="padding-left: 2.5rem; padding-right: 2.5rem;">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>
            </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
  </body>
</html>