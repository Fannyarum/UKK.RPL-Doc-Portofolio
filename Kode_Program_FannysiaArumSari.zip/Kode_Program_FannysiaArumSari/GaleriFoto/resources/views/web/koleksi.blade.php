<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/logoo.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
   <style>
        body {
            height: 100vh;
            padding-top: 20px;
            margin: 0;
            padding:0;
            display: flex;
            align-items: center;
            justify-content: center;
            background:url('img/bgg.jpg'); 
        }

        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            z-index: 99;
            box-shadow: 0 5px 15px rgba(0,0,0,.5);
        }

        .logo {
            font-size: 2em;
            color: #fff;
            user-select: none;
        }

        .navigation {
            display: flex;
            align-items: center;
        }

        .navigation a {
            font-size: 1.1em;
            color: #ffee97;
            text-decoration: none;
            font-weight: 500;
            margin-left: 20px;
            position: relative;
        }

        .banner{
            height:100vh;
            background:url('img/bgg.jpg');
            background-size:cover;
            background-position:center;
            width: 1350px;
        }

        .btn {
            background-color: #A498C3;
            padding: 6px 10px;
            border-radius: 20px;
            width: 100px;
            outline: none;
            border: none;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: 500;
            margin-left: 20px;
        }
        .btx {
            background-color: lightpink;
            padding: 6px 10px;
            border-radius: 20px;
            border-color: transparent;
            font-weight: 500;
            margin-left: 20px;
        }


        .btnn {
            background-color: #A498C3;
            padding: 6px 10px;
            border-radius: 20px;
            width: 170px;
            outline: none;
            border: none;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: 500;
            margin-left: 20px;
            box-shadow: -10px 10px 20px rgba(2, 0, 0, 0.5);
        }

        .btnlog {
            padding: 6px 10px;
            background: #808080;
            border: 2px solid #fff;
            outline: none;
            border-radius: 20px;
            cursor: pointer;
            font-size: 1.1em;
            color: #fff;
            font-weight: 500;
            margin-left: 20px;
            transition: .5s;
        }

        .btnlogin-popup:hover {
            background: #fff;
            color: #162938;
        }
        
        .card{
            padding: 0;
            margin: 15px 10px;
            border-radius:  var(--card_border_radius);
            background-color: #fff;
        }
      
        .box img{
            border-radius:15px;
        }
        .grid-foto{
            border-radius: 50px;
            width:50vh;
            height: 50vh;
            padding: 20px;
        }
        .grid{
            border-radius: 30px;
            width:340px;
            box-shadow:10px 10px 20px rgba(2, 0, 0, 0.5);
            transition: transform 0.6s;
        }
        .grid:hover{
            transform: translateY(-15px);
         }
        span{
            color:#162938;
            font-size: 25px;
        }
        h4{
            font-size:20px;
            color: #784B84;
            padding: 10px;
            text-shadow:5px 5px 10px rgba(2, 3, 0, 0.3);
            font-family: 'sans serif', 'Arial';

        }
      
        
    </style>
    <title>Album|Saya</title>
</head>
<body>  
    <header>
        <nav class="navigation">
        <a>
            <img  width="85" height="50" src="img/logo.png"></img>
        </a>
        <h5 class="fw-bold mx-5" style="color:#A498C3;">{{ session('user')->Username }}</h5>
        </nav>
        <nav class="navigation">
            <a href="/homee" class="text-dark mx-5 fw-bold">Home</a>
            <a href="/album" class="text-dark fw-bold">My Collection</a>
            
            <a href="/logout"><button class="btn btnlogin-popup shadow-sm">Logout</button></a>          
        </nav>
    </header>
     <section class="content vh-100">
        <br>
        <br>
        <br>
        <br>
        <div class="text-center">                                                                               
            <a href="/tambah"><button class="btnn"><span>+</span> Buat Album</button></a>
        </div>
        <br>
      
        <div class="container">
    <div class="row justify-content-center">
        @php
        $cekAlbum = false;
        @endphp

        @foreach($album as $alb)
            @if(session()->get('user')->UserID == $alb->UserID)
                @php
                $cekAlbum = true;
                @endphp
                <div class="card grid">
                    <a href="/albums{{ $alb->AlbumID }}"><img src="img/albums.jpg" class="grid-foto"></a>
                    <div class="card-body">
                        <h5 class="card-title">{{$alb->NamaAlbum}}</h5>
                        <p class="card-text" style="font-family: 'Comic Sans MS', arial;">{{$alb->Deskripsi}}</p>
                    </div>
                    <div class="d-flex justify-content-center">
                        <button class="btx btn-secondary">{{$alb->TanggalDibuat}}</button>
                    </div>
                    <br>
                </div>
            @endif
        @endforeach

        @if(!$cekAlbum)
        <div class="justify-content-center align-items-center">
            <div class="col-md-11">
                <br>
                <br>
                <br>
                <div class="bg-white p-4 rounded-5" style="width:700px; height:300px; box-shadow:2px 3px 20px rgba(0, 0, 0, 0.5);">
                    <br>
                    <br>
                    <br>
                    <br>
                    <h4 class="text-center fw-bold">Maaf, Anda belum memiliki album. Buatlah album terlebih dahulu untuk mengupload foto.</h4>
                </div>
            </div>
        </div>
        @endif
    </div>
</div>

        
        </div>
    </div>          
      </div> 
    </section>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>
