<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/logoo.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="https://getbootstrap.com/docs/5.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  
    

  <style>
     header {
            position: fixed;
            top: 0;
            width: 100%;
            background: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            z-index: 99;
            box-shadow: 0 5px 15px rgba(0,0,0,.5);
        }

        .logo {
            font-size: 2em;
            color: #fff;
            user-select: none;
        }

        .navigation {
            display: flex;
            align-items: center;
                   
        }

        .navigation a {
            font-size: 1.1em;
            color: #ffee97;
            text-decoration: none;
            font-weight: 500;
            margin-left: 20px;
            position: relative;
        }

        .banner{
            height:100vh;
            background:url('img/bgg.jpg');
            background-size:cover;
            background-position:center;
            width: 1350px;
        }

        .col {
            flex-basis: 60%; 
            margin: 15px;
        }
        h1{
            margin-left: 5px;
            font-size: 65px;
            text-shadow:5px 5px 10px rgba(2, 3, 0, 0.5);
            font-family: 'Comic Sans MS', Arial, courier,helvetica;
            color: #784B84;
            
        }
        span{
            color: #C64B8C;
            font-family: 'Comic Sans MS', cursive;
            font-size: 65px;
        }
        
        p{
            font-size:21px;
            color: #784B84;
            padding: 10px;
            text-shadow:5px 5px 10px rgba(2, 3, 0, 0.3);
            font-family: 'sans serif', 'Arial';
        
         }
         .cards{
            width: 200px;
            height: 230px;
            display: inline-block;
            border-radius: 10px 10px;
            box-sizing:border-box;
            margin: 15px 15px;
            background-position: center;
            background-size: cover;
            transition: transform 0.5s;
            box-shadow:5px 5px 10px rgba(2, 0, 0, 0.5);
        }
         .cards:hover{
           transform: translateY(-10px);
        }
         .card1{
            background-image: url(img/doi.jpg);

         }
         .card2{
            background-image: url(img/kun.jpg);
         }
         .card3{
            background-image: url(img/kol.jpg);
         }
         .card4{
            background-image: url(img/koll.jpg);
         }
         h5{
            color: #fff;
            text-shadow: 2px 3px 8px rgba(1, 2, 3, 2);        
         }
         .btt{
            padding: 0.5em 0.6em;
            background-color:#A498C3;  
            border-color: #A498C3;   
            border-radius: 25px;
            color: #fff;
         }
         .btu{
            padding: 0.5em 0.6em;
            background-color:#784B84;  
            border-color:transparent;   
            border-radius: 25px;
            color: #fff;
         }
         .btu:hover{
            background-color:#C64B8C;
         }
         .album .card {
            max-width: 340px; 
            margin: auto; 
        }

        .album .card-img-top {
            max-height: 350px; 
            object-fit: cover;
        }
         
       
    </style>
    <title>Beranda</title>
</head>
<body>  
<header>
     <a>
        <img  width="85" height="50" src="img/logo.png"></img>
    </a>
    <nav class="navigation">
        <a href="/login"><button class="btt fs-6">Sign In</button></a>
        <a href="/register"><button class="btu fs-6">Sign Up</button></a>
        </nav>
            
    </header>
    <section>
        <div class="banner">
            <br>
            <br>
            <br>
          
            <div class="row justify-content-center align-items-center ">
                <div class="col-lg-5">
                    <div class="col">
                    <div class="cards card1">
                    </div>

                    <div class="cards card2">
                    </div>

                    <div class="cards card3">
                    </div>

                    <div class="cards card4">
                    </div>
                </div>
            </div>
                <div class="col-xl-4 offset-xl-1">
                    <h1>
                        Galeri<span>Foto</span>
                    </h1>
                    <br>
                    <p class=fw-bold>Tempat di mana setiap momen berharga dapat diabadikan dalam bentuk foto dan album untuk dibagikan bersama pengguna lain </p>
                    <p><a href="#lihatview"><button class="btt shadow-lg fs-6">Lihat Foto <i class="fa fa-image"></i></button></a></p>

                  
                </div>
        <center>
            <main class="bg-light">
                     <br>
                     <br>

                    <div id="lihatview" class="row py-lg-5">
                    <div class="col-lg-6 mx-auto">
                        <h1 class="fw-dark">Fotos example</h1>
                        <p class="lead text-dark">Berikut merupakan foto-foto yang diunggah oleh pengguna lain. Login untuk membuat album pribadi, mengupload foto, berkomentar dan memberikan like.
                        </p>
                    </div>
                    </div>
                
                <div class="album py-5 bg-light">
                    <div class="container">
                    <div class="row row-cols-1 row-cols-md-3 g-3">
                        
                    <?php $__currentLoopData = $foto->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="cols">
                        <div class="card shadow-sm">
                            <div class="overlay">
                            <img src="<?php echo e(Storage::url($fotos->LokasiFile)); ?>" class="bd-placeholder-img card-img-top" width="100%" height="390px">
                            
                        </div>
                            <div class="card-body">
                            <p class="card-text"><?php echo e($fotos->DeskripsiFoto); ?></p>
                            <div class="d-flex align-items-center">
                            </div>
                            </div>
                        </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                   
            </main>
        </center>
    </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH D:\Kelas_12\GaleriFoto\resources\views/web/home.blade.php ENDPATH**/ ?>