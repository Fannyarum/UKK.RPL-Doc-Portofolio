<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="img/logoo.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
   <style>
        body {
            background:url('img/bgg.jpg'); 
            height: 100vh;
            padding-top: 20px;
            margin: 0;
            padding:0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            z-index: 99;
            box-shadow: 0 5px 15px rgba(0,0,0,.5);
        }

        .logo {
            font-size: 2em;
            color: #fff;
            user-select: none;
        }

        .navigation {
            display: flex;
            align-items: center;
        }

        .navigation a {
            font-size: 1.1em;
            color: #ffee97;
            text-decoration: none;
            font-weight: 500;
            margin-left: 20px;
            position: relative;
        }


        .btn {
            background-color: #A498C3;
            padding: 6px 10px;
            border-radius: 20px;
            width: 100px;
            outline: none;
            border: none;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: 500;
            margin-left: 20px;
        }

        .btnlog {
            padding: 6px 10px;
            background: #808080;
            border: 2px solid #fff;
            outline: none;
            border-radius: 20px;
            cursor: pointer;
            font-size: 1.1em;
            color: #fff;
            font-weight: 500;
            margin-left: 20px;
            transition: .5s;
        }
       
        .Container{
            width: 1400px;
            margin: 20px auto;
            columns: 4;
            column-gap: 40px;
            
        }
        .Container .box{
            width: 100%;
            margin-bottom: 10px;
            break-inside: avoid;
        }
        .Container .box img{
            max-width: 100%;
            border-radius: 15px;
        }

        .khusus{
            margin: 0;
            padding: 0;
            box-sizing: border-box;

        }
        .card{
            max-width: 150vh;
            flex-direction: row;
            height: 500px;
            border-radius: 25px;
            
        }
        .card img{
            max-width: 55vh;
            margin: auto;
            padding:25px;
            border-radius: 0.7em;
        }
        .card-body{
            display: flex;
            justify-content: space-between;

        }
        .text-section{
            max-width: 60%;
        }
        .cta-section{
            max-width: 40%;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            justify-content: space-between;
        }
        .cta-section .btt{
            padding: 0.3em 0.5em;
            background-color:#A498C3;  
            border-color: #A498C3;   
            border-radius: 25px;
            color: #fff;
        }
        .btt{
          padding: 0.5em 0.6em;
            background-color:#A498C3;  
            border-color: #A498C3;   
            border-radius: 25px;
            color: #fff;
            
         }
  
        .inpucol{
            background-color:#D3D3D3;
            border-radius:25px;
            width: 500px;
            padding: 20px;
            margin: 30px;
        }
        
    </style>
    <title>Beranda</title>
</head>
<body>  
    <header>
        <nav class="navigation">
        <a>
            <img  width="85" height="50" src="img/logo.png"></img>
        </a>
        <h5 class="fw-bold mx-5" style="color:#A498C3;"><?php echo e(session('user')->Username); ?></h5>
        </nav>
        <nav class="navigation">
            <a href="/homee" class="text-dark mx-5 fw-bold">Home</a>
            <a href="/album" class="text-dark fw-bold">My Collection</a>
            
            <a href="/logout"><button class="btn btnlogin-popup shadow-sm">Logout</button></a>          
        </nav>
    </header>
    <section class="content vh-100 khusus" style="padding-top:100px;">
    <br>
    <div class="card" style="box-shadow:2px 3px 20px rgba(0, 0, 0, 0.5); height: 72vh;">
    <img src="<?php echo e(Storage::url($foto->LokasiFile)); ?>" class="card-img-top">
    <div class="card-body" style="display: flex; flex-direction: column; justify-content: space-between;">
        <div class="text-section"> 
            <br>
            <h3 class="card-title"><?php echo e($foto->JudulFoto); ?></h3>
            <br>
            <br>
            <p class="card-text"><?php echo e($foto->DeskripsiFoto); ?></p>
        </div>
        <div style="margin-top: auto;">
            <button class="btt">
                <?php if($cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $foto->FotoID)->first()): ?>
                    <a href="/like<?php echo e($foto->FotoID); ?>"><i class="fa fa-heart" style="color:#d32f2f; width:50px;"></i></a>
                    <?php echo e($like->where('FotoID', $foto->FotoID)->count()); ?>

                <?php else: ?>
                    <a href="/like<?php echo e($foto->FotoID); ?>"><i class="fa fa-heart" style="color:pink; width:50px;"></i></a>
                    <?php echo e($like->where('FotoID', $foto->FotoID)->count()); ?>

                <?php endif; ?>
            </button>
            <a href="#inikomen"><button class="btt"><i class="fa fa-comment" style="color:pink; width:50px;"></i><?php echo e($komen->where('FotoID', $foto->FotoID)->count()); ?></button></a>
            <button class="btt"><?php echo e($user->NamaLengkap); ?></button>
            <a href="/hapus<?php echo e($foto->FotoID); ?>">
                <?php if(session('user')->UserID == $foto->UserID): ?>
                    <button class="btt"><i class="fa fa-trash" style="color:pink; width:50px;"></i></button>
                <?php endif; ?>
            </a>
        </div>
    </div>
</div>

    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
        <center>
            <form action="/foto<?php echo e($FotoID); ?>" method="post">
                <div id="inikomen">
                        <?php echo csrf_field(); ?>
                        
                        <label>Komentar:</label>
                        <input type="text" class="inpucol" name="IsiKomentar" placeholder="Tulis komentar di sini...">
                        <br>
                        
                        <button type="submit" class="btt">Kirim</button>
                    </form>
                    <br>
                    <br>
                    <?php $__currentLoopData = $komen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <table class="table table-hover" style="box-shadow:2px 3px 20px rgba(0, 0, 0, 0.5);">
                        <tr>
                            <td class="fw-bold">
                    <?php
                        $user = \App\Models\User::find($ft->UserID);
                    ?>
                    <span>@</span><?php echo e($user->Username); ?> :</td>
                        </tr>
                        <tr>
                            <td><?php echo e($ft->IsiKomentar); ?></td>
                         </tr>
                    </table>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                    <br>
            </div>
        </center>
    </section>
</body>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</html>
<?php /**PATH D:\Kelas_12\GaleriFoto\resources\views/web/foto.blade.php ENDPATH**/ ?>