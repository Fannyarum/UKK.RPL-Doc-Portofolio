<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/logoo.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
   <style>
        body {
            background:url('img/bgg.jpg');
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container-custom { 
            background: rgba(255, 255, 255, 1); 
            padding: 30px;
            border-radius: 10px;
        }
        .btn{
            background-color:#A498C3;
            padding: 6px 10px;
            border-radius:20px;
        }
        .inpucol{
            background-color:#D3D3D3;
            border-radius:25px;
        }
        .form-table {
        width: 100%;
        }

        .form-label {
            display: inline-block;
            width: 35px;
        }

    
    </style>
    <title>Register</title>
</head>
<body>
    <section class="vh-80">
            
            <div class="row d-flex justify-content-center align-items-center">
                    <div class="bg-white p-4 rounded" style="width:150vh; box-shadow:2px 3px 20px rgba(0, 0, 0, 0.5);">
                        <h1 class="fs-8 text-center">Daftar</h1>
                        <br>
                        <table>
                            <form action="/register" method="post" >
                                 <?php echo csrf_field(); ?>         
                                <tr>
                                    <td><label class="fw-bold" style="width:200px;">Username</label></td>
                                    <td><label class="form-label fw-bold">: </label></td>
                                    <td><input type="text" name="Username" required class="form-control form-control-lg inpucol" style="width:600px;"/></td>
                                </tr>

                                <tr>
                                    <td><label class="fw-bold">Password</label></td>
                                    <td><label class="fw-bold">: </label></td>
                                    <td><input type="password" name="Password" required  class="form-control form-control-lg inpucol" style="width:600px;" /></td>
                                </tr>

                                <tr>
                                    <td><label class="fw-bold">Email</label></td>
                                    <td><label class="fw-bold">: </label></td>
                                    <td><input type="email" name="Email" required class="form-control form-control-lg inpucol" style="width:600px;"/></td>
                                </tr>

                                <tr>
                                    <td><label class="fw-bold" >Nama Lengkap</label></td>
                                    <td><label class="fw-bold">: </label></td>
                                    <td><input type="text" name="NamaLengkap" required class="form-control form-control-lg inpucol" style="width:600px;"/></td>
                                </tr>

                                <tr>
                                    <td><label class="fw-bold">Alamat</label></td>
                                    <td><label class="fw-bold">: </label></td>
                                    <td><textarea  name="Alamat" required class="form-control form-control-lg inpucol" style="width:600px;"></textarea></td>
                                </tr>

                                <tr>
                                    <td>
                                    <td>
                                        <td><div class="mt-4 pt-2">
                                        <input type="submit" value="Daftar" class="fw-bold btn"
                                            style="margin-left:25vh; padding-left: 2.5rem; padding-right: 2.5rem;">
                                            </div>
                                        </td>
                                    </td>
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </div>
                </div> 
    </section>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH D:\Kelas_12\GaleriFoto\resources\views/masuk/regis.blade.php ENDPATH**/ ?>