<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/logoo.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
   <style>
           body {
            background:url('img/bgg.jpg'); 
            height: 100vh;
            padding-top: 20px;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }


        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            z-index: 99;
            box-shadow: 0 5px 15px rgba(0,0,0,.5);
        }

        .logo {
            font-size: 2em;
            color: #fff;
            user-select: none;
        }

        .navigation {
            display: flex;
            align-items: center;
                   
        }

        .navigation a {
            font-size: 1.1em;
            color: #ffee97;
            text-decoration: none;
            font-weight: 500;
            margin-left: 20px;
            position: relative;
        }

        .btn {
            background-color: #A498C3;
            padding: 6px 10px;
            border-radius: 20px;
            width: 100px;
            outline: none;
            border: none;
            font-size: 1.1em;
            font-weight: 500;
            margin-left: 20px;
        }

        .btn:hover {
            background: #fff;
            color: #162938;
        }

        .Container{
            width: 1000px;
            margin: 20px auto;
            columns: 4;
            padding: 0;
            column-gap: 30px; 
        }

        .Container .box {
            width: 100%;
            height: 250px; 
            margin-bottom: 20px;
            break-inside: avoid;
            transition: transform 0.5s;
            position: relative;
            overflow: hidden;
            border-radius: 15px;
        }

        .Container .box img{
            width: 100%;
            height: 250px; 
            border-radius: 15px;
            transition: transform 0.5s;
        }

        .Container .box:hover img {
            filter: brightness(0.8); 
            transform: scale(1.05);
        }

        .Container .box::before {
            content: attr(data-title); 
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 20px;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 1);
            opacity: 0;
            transition: opacity 0.3s ease;
            z-index: 1;
            
        }
        .Container .box:hover::before {
            opacity: 1;
        }

    /* gapapa bro */
        .box:hover{
            transform: translateY(-5px);
            box-shadow:5px 5px 10px rgba(2, 0, 0, 0.5);
            border-radius: 20px; 
         } 
    
    </style>
    <title>Beranda</title>
</head>
<body>  
    <header>
        <nav class="navigation">
        <a>
            <img  width="85" height="50" src="img/logo.png"></img>
        </a>
        <h5 class="fw-bold mx-5" style="color:#A498C3;"><?php echo e(session('user')->Username); ?></h5>
        </nav>
        <nav class="navigation">
            <a href="/homee" class="text-dark mx-5 fw-bold">Home</a>
            <a href="/album" class="text-dark fw-bold">My Collection</a>
            
            <a href="/logout"><button class="btn btnlogin-popup shadow-sm">Logout</button></a>          
        </nav>
    </header>
    <section class="content vh-100">
        <br>
        <br>
        <br>
        <br>
        
        <p class="fw-bold text-center text-success"><?php echo e(session()->get('success')); ?></p> 
        <div class="Container">   
            <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <?php
            $user = \App\Models\User::find($fotos->UserID);
            ?>      
            <div class="box" data-title="<?php echo e($user->Username); ?>"><a href="/foto<?php echo e($fotos->FotoID); ?>">
            <img src="<?php echo e(Storage::url($fotos->LokasiFile)); ?>"></a></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>

<?php /**PATH D:\Kelas_12\GaleriFoto\resources\views/web/homepage.blade.php ENDPATH**/ ?>