<?php

use App\Http\Controllers\GaleriController;
use Illuminate\Support\Facades\Route;

Route::get('/home', [GaleriController::class, 'index']);

Route::get('/login', [GaleriController::class ,'tampilog']);
Route::post('/login', [GaleriController::class, 'login']);
Route::get('/logout', [GaleriController::class, 'logout']);

Route::get('/register', [GaleriController::class, 'tampilreg']);
Route::post('/register', [GaleriController::class, 'aksiDariRegister']);

Route::get('/homee', [GaleriController::class, 'homepage']);

Route::get('/album', [GaleriController::class, 'tampilalbum']);

Route::get('/tambah', [GaleriController::class, 'buatAlbum']);
Route::post('/tambah', [GaleriController::class, 'buatAlbumAksi']);

Route::get('/unggah', [GaleriController::class, 'unggah']);
Route::post('/unggah', [GaleriController::class, 'unggahFoto']);

Route::get('/albums{FotoID}', [GaleriController::class, 'viewal']);

Route::get('/foto{FotoID}', [GaleriController::class, 'view']);

Route::post('/foto{FotoID}', [GaleriController::class, 'komentar']);

Route::get('/like{FotoID}', [GaleriController::class, 'likefoto']);

Route::get('/hapus{FotoID}', [GaleriController::class, 'hapusfoto']);








