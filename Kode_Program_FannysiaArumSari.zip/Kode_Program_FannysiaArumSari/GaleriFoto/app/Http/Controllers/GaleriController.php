<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Album;
use App\Models\Foto;
use App\Models\Komen;
use App\Models\Like;

class GaleriController extends Controller
{
    public function index(){
        $foto = Foto::all();
        return view('web.home', compact('foto'));
    }

    public function tampilog(){
        return view('masuk.login');
    }

    public function login(Request $request){

        $data = User::where('Email', $request->input('Email'))->where('Password', $request->input('Password'))->first();
        if($data == null){
            return redirect()->back()->with('warning', 'Username/Password Anda Salah!!');
        }else{
            session()->put('user', $data);
            return redirect('/homee');
        }
    }

    public function logout(){
        session()->flush();
        return redirect('/home');
    }

    public function tampilreg(){

        return view ('masuk.regis');
    }

    public function aksiDariRegister(Request $request) {

        $data = new User();
        $data->Username = $request->input('Username');
        $data->Password =$request->input('Password');
        $data->Email =$request->input('Email');
        $data->NamaLengkap= $request->input('NamaLengkap');
        $data->Alamat =$request->input('Alamat');

        $data->save();
        return redirect('/login');
    }
    public function homepage(){
        $foto = Foto::all();
        return view('web.homepage', compact('foto'));
    }

    public function tampilalbum(){
        $album = Album::all();
        return view('web.koleksi', compact('album'));
    }

    public function buatAlbum(){
        return view('web.tambahA');
    }

    public function buatAlbumAksi(Request $request){
        $data = new Album();
        $data->NamaAlbum = $request->input('NamaAlbum');
        $data->Deskripsi= $request->input('Deskripsi');
        $data->TanggalDibuat = now ();
        $data->USerID = session('user')->UserID;

        $data->save();
        return redirect('/album');
    }

    public function unggah() {
        $album = Album::where('UserID', session('user')->UserID)->get();

        return view('web.unggah', compact('album'));
    }

    public function unggahFoto (Request $request){
        if($request->hasFile('foto')){
            $penyimpanan = $request->file('foto')->store('public/inifoto');

            $data = new Foto();
            $data->JudulFoto = $request->input('JudulFoto');
            $data->DeskripsiFoto = $request->input('DeskripsiFoto');
            $data->TanggalUnggah = now ();
            $data->LokasiFile = $penyimpanan;
            $data->AlbumID = $request->get('album');
            $data->UserID = session('user')->UserID;

            $data->save();
            return redirect('/homee');
        }else{
            return redirect()->back()->with('error', 'Gagal mengunggah foto!!');
        }
    }

    public function view($FotoID)
    {    
        $komen = Komen::where('FotoID', $FotoID)->get();
        $foto = Foto::find($FotoID); 
        $like = Like::all(); 
        $user = User::find($foto->UserID);

        return view('web.foto', compact('foto', 'like','user','komen','FotoID'));
    }

    public function viewal($AlbumID)
    {
        $album = Album::find($AlbumID);
        $foto = Foto::where('AlbumID', $AlbumID)->get();
        return view('web.album', compact('album', 'foto'));
    
    }

    public function komentar(Request $request, $FotoID){
        $data= new Komen();
        $data->FotoID = $FotoID;
        $data->UserID = session('user')->UserID;
        $data->IsiKomentar = $request->input('IsiKomentar');
        $data->TanggalKomentar = now();

        $data->save();
        return redirect('/foto' . $FotoID . '#inikomen');
    }

    public function likefoto($FotoID){
        $cek = Like::where('UserID', session('user')->UserID)->where('FotoID', $FotoID)->first();
        if(!$cek){
            $like = new Like;
            $like->FotoID = $FotoID;
            $like->UserID = session('user')->UserID;
            $like->TanggalLike = now();
            $like->save();
            
            return redirect()->back();
        }else{
            $cek->delete();

            return redirect()->back();
        }
    }
    public function hapusfoto($FotoID) {
        $data = Foto::find($FotoID);
        
        $data->delete();
        return redirect('/homee')->with('success', 'Data berhasil dihapus');
    }


}
